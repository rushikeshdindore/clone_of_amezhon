const leftbtn=document.querySelector(".l-btn");
const rightbtn=document.querySelector(".r-btn");

leftbtn.addEventListener('click',function(event){
    console.log('Done');
    const move =document.querySelector('.products-slide');
    move.scrollLeft-=1100;
    event.preventDefault();
});
rightbtn.addEventListener('click',function(event){
    console.log('Done');
    const move =document.querySelector('.products-slide');
    move.scrollLeft+=1100;
    event.preventDefault();
})

const lefbtn1 =document.querySelector(".newbtn-1b");
const rigtbtn1 =document.querySelector(".newbtn-1a");

lefbtn1.addEventListener('click',function(event){
    console.log('Done');
    const conent = document.querySelector('.productslide-1');
    conent.scrollLeft-=1100;
    event.preventDefault();
});
rigtbtn1.addEventListener('click',function(event){
    console.log('Done');
    const conent =document.querySelector('.productslide-1');
    conent.scrollLeft+=1100;
    event.preventDefault();
})

